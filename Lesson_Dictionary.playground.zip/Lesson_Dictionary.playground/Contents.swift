//Declaring
//let emptyDict:[Int:String] = [:]
//print(emptyDict)
//
//
//let emptyDic:Dictionary<Int, String> = [:]
//print(emptyDic)
//
//let someDict = ["a":1, "b":2, "c":3, "d":4, "e":5, "f":6, "g":7, "h":8, "i":9]
//print(someDict["a"]!)
//
//let customKeys = ["Facebook", "Google", "Amazon"]
//let customValues = ["Mark", "Larry", "Jeff"]
//let newDictionary = Dictionary(uniqueKeysWithValues: zip(customKeys,customValues))
//print(newDictionary["Amazon"]!)

/

//let someDic = ["a":1, "b":2, "c":3, "d":4, "e":5, "f":6, "g":7, "h":8, "i":9]
//for (key,value) in someDic {
//    print("key:\(key) value:\(value)")
//}


//var someDictionary = ["Nepal":"Kathmandu", "China":"Beijing", "India":"NewDelhi"]
//let val  = someDictionary.removeValue(forKey: "Nepal")
//print(val!)
//print(someDictionary)
